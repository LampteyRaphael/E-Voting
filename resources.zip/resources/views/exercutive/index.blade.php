@extends('layouts.app')

@section('content')
    @include('includes.admin')
@endsection