@extends('layouts.app')

@section('content')

          <span class="panel col-md-8 col-md-offset-2 bg-dark">
              <span class="panel-body">
                  <h1>
                      <span class="error-subtext-w3l">
                      <i class="fas fa-exclamation-circle text-warning mr-3"></i>Oops you have encountered an error</span>
                  </h1>

                  <p class="error-text"> It appears the page you are looking for doesn't exist. Sorry about that.</p>
              </span>
          </div>

@endsection