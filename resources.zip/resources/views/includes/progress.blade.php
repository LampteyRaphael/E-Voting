<div class="container1" style="padding-bottom: 100px;">
    <ul class="progressbar">
        <li class="active">Chairmanship</li>
        <li id="secretary">Secretary</li>
        <li id="financial">Financial Secretary</li>
        <li id="organizer">Organizer</li>
        <li id="executive">Executive Members</li>
    </ul>
</div>