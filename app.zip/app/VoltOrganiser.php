<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class VoltOrganiser extends Model
{
    //
    protected $fillable=[

        'name',
        'user_id',
    ];

}
