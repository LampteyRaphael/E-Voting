<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class VoltChairman extends Model
{
    //
    protected $fillable=[
        'name',
        'user_id',
    ];
}
