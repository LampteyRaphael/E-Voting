<?php
namespace App\Http\Controllers;
use App\Http\Requests\SecretaryVoltRequest;
use App\PostSecretary;
use App\SecretaryCreate;
use App\User;
use Illuminate\Http\Request;

class PostSecretaryController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $users=SecretaryCreate::all();

        return view('secretary.index',compact('users'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        $users=User::all();

        return view('secretary.create',compact('users'));
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(SecretaryVoltRequest $request)
    {
        //
        $post=$request->all();

        $user=new PostSecretary();

        $user->name=$post['name'];

        $user->user_id=$post['user_id'];

        $user->save();

        return redirect()->route('financial.index')->with(['success'=>'You have Successfully Voted For Secretary Position.Thank You']);
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        //




    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
    }
}
